﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoriesManagment
{
    public class UpdatePriceListInInventory : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            string messageType = context.MessageName;

            tracingService.Trace($"messageType {messageType}");

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity inventoryEntity = (Entity)context.InputParameters["Target"];
                if (inventoryEntity.Contains("new_fk_price_list"))
                {
                    EntityReference priceListLookup = (EntityReference)inventoryEntity["new_fk_price_list"];
                    Guid priceListId = priceListLookup.Id;
                    tracingService.Trace($"priceListId {priceListId} ");
                    tracingService.Trace($"inventoryEntityId {inventoryEntity.Id} ");
                    // until this work but get an error, why?
                    //EntityCollection inventoryProducts = getInventoryProducts(inventoryEntity.Id, service);




                }
            }

        }
        public EntityCollection getInventoryProducts(Guid inventoryId, IOrganizationService service)
        {
            QueryExpression queryInventoryProducts = new QueryExpression
            {

                EntityName = "new_inventory_product",
                ColumnSet = new ColumnSet("new_total_amount"),
                Criteria =
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                        new ConditionExpression("new_fk_inventory", ConditionOperator.Equal, inventoryId)
                    }
                }

            };
            return service.RetrieveMultiple(queryInventoryProducts);
        }


    }
}
